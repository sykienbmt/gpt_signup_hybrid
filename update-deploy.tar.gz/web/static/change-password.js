/* gpt_signup_hybrid — Change Password tab
 * Input: combos (email|current_pass|2fa) + new password
 * Per-item: browser login → Settings → Security → change password
 * Features: per-item retry, End-all, click-email-to-copy, export success
 */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const dom = {
    input:       $('cp2-input'),
    newPass:     $('cp2-new-pass'),
    randomPass:  $('cp2-random-pass'),
    parallel:    $('cp2-parallel'),
    btnRun:      $('cp2-btn-run'),
    btnEnd:      $('cp2-btn-end'),
    btnClear:    $('cp2-btn-clear'),
    btnExport:   $('cp2-btn-export'),
    count:       $('cp2-count'),
    resultList:  $('cp2-result-list'),
    summary:     $('cp2-summary'),
  };

  // ── State ─────────────────────────────────────────────────────────────
  let _combos      = [];   // [{email, pass, secret, newPass}]
  let _results     = [];   // null | {success, error, logs}
  let _controllers = [];   // AbortController | null per item
  let _running     = false;
  let _aborted     = false;

  // ── Helpers ───────────────────────────────────────────────────────────
  function escHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c =>
      ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function copyText(t) {
    if (window.GptUi?.copyText) return window.GptUi.copyText(t);
    return navigator.clipboard?.writeText(t);
  }

  function flash(msg) {
    const el = document.createElement('div');
    el.className = 'flash-msg';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2200);
  }

  function makeid(n = 8) {
    return Math.random().toString(36).slice(2, 2 + n);
  }

  function randomPassword() {
    const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#$';
    let p = '';
    for (let i = 0; i < 14; i++) p += chars[Math.floor(Math.random() * chars.length)];
    return p;
  }

  // ── Parse input ───────────────────────────────────────────────────────
  function parseInput() {
    const lines = dom.input.value.split('\n').map(l => l.trim()).filter(Boolean);
    const newPassBase = dom.randomPass?.checked ? null : (dom.newPass?.value?.trim() || null);
    return lines.map(line => {
      const parts = line.split('|').map(p => p.trim());
      return {
        email:   parts[0] || '',
        pass:    parts[1] || '',
        secret:  parts[2] || '',
        newPass: newPassBase ?? randomPassword(),
        _raw:    line,
      };
    }).filter(c => c.email && c.pass);
  }

  function updateCount() {
    const combos = parseInput();
    dom.count.textContent = `${combos.length} combo${combos.length !== 1 ? 's' : ''}`;
  }

  // ── Render ────────────────────────────────────────────────────────────
  function render() {
    const done   = _results.filter(r => r !== null).length;
    const ok     = _results.filter(r => r?.success).length;
    const failed = _results.filter(r => r !== null && !r?.success).length;
    dom.summary.textContent = _combos.length
      ? `${done}/${_combos.length} done · ${ok} ok · ${failed} failed`
      : '';

    if (!_combos.length) {
      dom.resultList.innerHTML = '<div class="empty">Paste combos and click Run.</div>';
      return;
    }

    dom.resultList.innerHTML = _combos.map((c, i) => {
      const res = _results[i];
      const ctrl = _controllers[i];
      const inFlight = ctrl !== null;

      let statusIcon = '⏳';
      let statusClass = 'status-pending';
      if (res !== null) {
        if (res.success) { statusIcon = '✅'; statusClass = 'status-success'; }
        else             { statusIcon = '❌'; statusClass = 'status-error'; }
      } else if (inFlight) {
        statusIcon = '🔄'; statusClass = 'status-running';
      }

      const emailEl = `<span class="email-copy" data-idx="${i}" title="Click to copy email">${escHtml(c.email)}</span>`;
      const errEl = res && !res.success
        ? `<span class="cp2-error-msg muted">${escHtml(res.error || 'unknown error')}</span>`
        : '';
      const newPassEl = res?.success
        ? `<span class="cp2-new-pass-badge" title="New password (click to copy)" data-newpass="${escHtml(c.newPass)}">${escHtml(c.newPass)}</span>`
        : '';

      const retryBtn = res !== null && !inFlight
        ? `<button class="btn btn-ghost btn-small cp2-retry" data-idx="${i}">🔄 Retry</button>`
        : '';
      const cancelBtn = inFlight
        ? `<button class="btn btn-ghost btn-small cp2-cancel" data-idx="${i}">✕</button>`
        : '';
      const logsBtn = res?.logs?.length
        ? `<button class="btn btn-ghost btn-small cp2-logs" data-idx="${i}">📋 Logs</button>`
        : '';

      return `<div class="cp2-row ${statusClass}" data-idx="${i}">
        <span class="cp2-status">${statusIcon}</span>
        ${emailEl}
        ${newPassEl}
        ${errEl}
        <span class="cp2-actions">${retryBtn}${cancelBtn}${logsBtn}</span>
      </div>`;
    }).join('');
  }

  // ── API call ──────────────────────────────────────────────────────────
  async function runOne(i) {
    const c = _combos[i];
    if (!c) return;

    const ctrl = new AbortController();
    _controllers[i] = ctrl;
    _results[i] = null;
    render();

    const combo = c.secret ? `${c.email}|${c.pass}|${c.secret}` : `${c.email}|${c.pass}`;

    try {
      const resp = await fetch('/api/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ combo, new_password: c.newPass }),
        signal: ctrl.signal,
      });
      const data = await resp.json();
      _results[i] = data;
    } catch (err) {
      if (err.name === 'AbortError') {
        _results[i] = { success: false, email: c.email, error: 'Cancelled', logs: [] };
      } else {
        _results[i] = { success: false, email: c.email, error: String(err), logs: [] };
      }
    } finally {
      _controllers[i] = null;
      render();
    }
  }

  async function runPool(indices, limit) {
    const queue = [...indices];
    const workers = Array.from({ length: limit }, async () => {
      while (queue.length && !_aborted) {
        const i = queue.shift();
        if (i === undefined) break;
        await runOne(i);
      }
    });
    await Promise.all(workers);
  }

  // ── Run ───────────────────────────────────────────────────────────────
  async function start() {
    _combos      = parseInput();
    _results     = _combos.map(() => null);
    _controllers = _combos.map(() => null);
    _aborted     = false;
    _running     = true;

    dom.btnRun.disabled = true;
    dom.btnEnd.style.display = '';
    render();

    const limit = parseInt(dom.parallel?.value || '1', 10);
    await runPool(_combos.map((_, i) => i), limit);

    _running = false;
    dom.btnRun.disabled = false;
    dom.btnEnd.style.display = 'none';
    render();
  }

  // ── Export ────────────────────────────────────────────────────────────
  function doExport() {
    const lines = _combos
      .map((c, i) => _results[i]?.success ? `${c.email}|${c.newPass}|${c.secret}` : null)
      .filter(Boolean);
    if (!lines.length) { flash('No successful results to export'); return; }
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `changed-passwords-${Date.now()}.txt`;
    a.click();
  }

  // ── Show logs modal ───────────────────────────────────────────────────
  function showLogs(i) {
    const res = _results[i];
    if (!res?.logs?.length) return;
    const c = _combos[i];
    const modal = document.createElement('div');
    modal.className = 'cp2-log-modal';
    modal.innerHTML = `
      <div class="cp2-log-backdrop"></div>
      <div class="cp2-log-box">
        <div class="cp2-log-head">
          <span>📋 Logs — ${escHtml(c.email)}</span>
          <button class="icon-btn cp2-log-close">✕</button>
        </div>
        <pre class="cp2-log-body">${escHtml(res.logs.join('\n'))}</pre>
      </div>`;
    document.body.appendChild(modal);
    modal.querySelector('.cp2-log-backdrop').onclick = () => modal.remove();
    modal.querySelector('.cp2-log-close').onclick = () => modal.remove();
  }

  // ── Event delegation ─────────────────────────────────────────────────
  dom.resultList.addEventListener('click', async (e) => {
    const t = e.target.closest('[data-idx]');
    if (!t) return;
    const i = parseInt(t.dataset.idx, 10);

    if (t.classList.contains('cp2-retry')) {
      await runOne(i);
    } else if (t.classList.contains('cp2-cancel')) {
      _controllers[i]?.abort();
    } else if (t.classList.contains('cp2-logs')) {
      showLogs(i);
    } else if (t.classList.contains('email-copy')) {
      await copyText(_combos[i]?.email || '');
      flash('Copied email');
    } else if (t.classList.contains('cp2-new-pass-badge')) {
      await copyText(t.dataset.newpass || '');
      flash('Copied new password');
    }
  });

  dom.btnRun.addEventListener('click', () => { if (!_running) start(); });

  dom.btnEnd.addEventListener('click', () => {
    _aborted = true;
    _controllers.forEach(ctrl => ctrl?.abort());
  });

  dom.btnClear.addEventListener('click', () => {
    dom.input.value = '';
    _combos = []; _results = []; _controllers = [];
    updateCount(); render();
  });

  dom.btnExport.addEventListener('click', doExport);

  dom.input.addEventListener('input', updateCount);

  dom.randomPass?.addEventListener('change', () => {
    dom.newPass.disabled = !!dom.randomPass.checked;
  });

  // Initial count
  updateCount();
  render();
})();
