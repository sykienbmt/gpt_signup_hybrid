"""Change ChatGPT account password via browser automation.

Flow:
    1. Browser login (same as session_phase)
    2. Settings → Security → click password field → auth.openai.com
    3. Verify current password
    4. Enter new password (×2) and submit
    5. If MFA challenge → fill TOTP code
"""
from __future__ import annotations

import asyncio
import shutil
import time
import uuid
from typing import Any, Callable

from ._browser_retry import (
    LAUNCH_RETRY_BACKOFF as _BACKOFF,
    LAUNCH_RETRY_MAX as _RETRY_MAX,
    is_driver_dead_error as _is_dead,
)
from ._nextauth_bootstrap import bootstrap_authorize_url
from .config import load_settings
from .totp_helper import generate_code

LogFn = Callable[[str], None]


class ChangePasswordError(Exception):
    """Password change failed."""


async def change_password(
    *,
    email: str,
    current_password: str,
    new_password: str,
    secret: str | None = None,
    headless: bool = True,
    proxy: str | None = None,
    log: LogFn = print,
) -> None:
    """Change ChatGPT account password. Raises ChangePasswordError on failure."""
    settings = load_settings()
    job_id = f"chpwd_{uuid.uuid4().hex[:10]}"
    proxy_kwargs: dict[str, Any] = {}
    if proxy:
        proxy_kwargs["proxy"] = {"server": proxy}

    preferred = (settings.browser_engine or "camoufox").lower()
    engine_order = ["camoufox", "chromium"] if preferred == "camoufox" else ["chromium"]
    w, h = settings.browser_viewport_width, settings.browser_viewport_height
    viewport = {"width": w, "height": h}

    last_err: Exception | None = None
    for attempt in range(1, _RETRY_MAX + 1):
        engine = engine_order[(attempt - 1) % len(engine_order)]
        if engine == "camoufox":
            profile_dir = settings.profiles_dir / f"camoufox_{job_id}"
        else:
            profile_dir = settings.profiles_dir / job_id

        if profile_dir.exists():
            shutil.rmtree(profile_dir, ignore_errors=True)
        profile_dir.mkdir(parents=True, exist_ok=True)

        try:
            if engine == "camoufox":
                from camoufox.async_api import AsyncCamoufox

                async with AsyncCamoufox(
                    headless=headless,
                    geoip=True,
                    user_data_dir=str(profile_dir),
                    **proxy_kwargs,
                ) as browser:
                    ctx = await browser.new_context(viewport=viewport)
                    page = await ctx.new_page()
                    await _drive(ctx, page, email, current_password, new_password, secret, h, log)
                    return
            else:
                from playwright.async_api import async_playwright

                async with async_playwright() as pw:
                    browser = await pw.chromium.launch(headless=headless, args=["--no-sandbox"])
                    ctx = await browser.new_context(viewport=viewport, **proxy_kwargs)
                    page = await ctx.new_page()
                    try:
                        await _drive(ctx, page, email, current_password, new_password, secret, h, log)
                        return
                    finally:
                        await browser.close()

        except ChangePasswordError:
            raise
        except Exception as exc:
            if _is_dead(exc) and attempt < _RETRY_MAX:
                log(f"[chpwd] driver error (attempt {attempt}): {exc} — retry in {_BACKOFF}s")
                await asyncio.sleep(_BACKOFF)
                last_err = exc
                continue
            raise ChangePasswordError(f"Browser error: {exc}") from exc

    raise ChangePasswordError(f"Failed after {_RETRY_MAX} attempts: {last_err}")


async def _drive(
    ctx: Any, page: Any,
    email: str, current_password: str, new_password: str,
    secret: str | None, viewport_h: int, log: LogFn,
) -> None:
    """Full browser flow: login → settings → password change."""
    device_id = str(uuid.uuid4())
    logging_id = str(uuid.uuid4())

    # Phase 1: Login to chatgpt.com
    log("[chpwd] loading chatgpt.com...")
    await page.goto("https://chatgpt.com/", wait_until="domcontentloaded")
    authorize_url = await bootstrap_authorize_url(
        page, email=email, device_id=device_id, logging_id=logging_id,
    )
    await page.goto(authorize_url, wait_until="domcontentloaded")
    await asyncio.sleep(3.0)

    if "/log-in/password" not in page.url:
        for sel in ('input[name="email"]', 'input[type="email"]'):
            try:
                loc = page.locator(sel).first
                if await loc.is_visible(timeout=8000):
                    await loc.click(force=True)
                    await loc.fill("")
                    await loc.type(email, delay=30)
                    for btn in ('button[type="submit"]', 'button:has-text("Continue")'):
                        try:
                            await page.click(btn, timeout=3000)
                            break
                        except Exception:
                            continue
                    await asyncio.sleep(3.0)
                    break
            except Exception:
                continue

    pwd_input = None
    for sel in ('input[type="password"]', 'input[name="password"]'):
        try:
            loc = page.locator(sel).first
            if await loc.is_visible(timeout=15000):
                pwd_input = loc
                break
        except Exception:
            continue
    if not pwd_input:
        raise ChangePasswordError(f"Login password field not found. URL: {page.url}")

    await pwd_input.click(force=True)
    await pwd_input.fill("")
    await pwd_input.type(current_password, delay=40)
    for btn in ('button[type="submit"]', 'button:has-text("Continue")', 'button:has-text("Log in")'):
        try:
            await page.click(btn, timeout=3000)
            break
        except Exception:
            continue
    await asyncio.sleep(3.0)
    await _fill_mfa_if_needed(page, secret, log, step="login")

    # Wait for chatgpt.com
    deadline = time.monotonic() + 30.0
    while time.monotonic() < deadline:
        if "chatgpt.com" in page.url and "auth.openai.com" not in page.url:
            break
        await asyncio.sleep(1.0)
    if "auth.openai.com" in page.url:
        raise ChangePasswordError(f"Login failed — still on auth page. URL: {page.url}")
    log(f"[chpwd] login OK. URL: {page.url.split('?')[0]}")

    # Phase 2: Navigate to password change via Settings → Security
    await asyncio.sleep(2.0)
    menu_opened = False
    for sel in ('[data-testid="profile-button"]', '[data-testid="user-menu-button"]'):
        try:
            if await page.locator(sel).is_visible(timeout=2000):
                await page.click(sel, timeout=3000)
                menu_opened = True
                log(f"[chpwd] opened user menu via {sel}")
                break
        except Exception:
            continue
    if not menu_opened:
        await page.mouse.click(50, viewport_h - 50)
        log("[chpwd] clicked bottom-left for user menu")
    await asyncio.sleep(1.0)

    settings_clicked = False
    for sel in (
        '[data-testid="settings-menu-item"]',
        '[role="menuitem"]:has-text("Settings")',
        'button:has-text("Settings")',
    ):
        try:
            await page.click(sel, timeout=4000)
            settings_clicked = True
            log("[chpwd] settings opened")
            break
        except Exception:
            continue
    if not settings_clicked:
        raise ChangePasswordError("Cannot open Settings — UI may have changed")
    await asyncio.sleep(1.5)

    for sel in ('[data-testid="security-tab"]', 'button:has-text("Security")', 'button:has-text("Bảo mật")'):
        try:
            await page.click(sel, timeout=5000)
            log("[chpwd] security tab opened")
            break
        except Exception:
            continue
    else:
        raise ChangePasswordError("Cannot find Security tab in settings")
    await asyncio.sleep(1.0)

    pwd_field_clicked = False
    for sel in ('[data-testid="password-setting"]', '[data-testid="password-setting"] > div'):
        try:
            await page.click(sel, timeout=4000)
            pwd_field_clicked = True
            log("[chpwd] password field clicked")
            break
        except Exception:
            continue
    if not pwd_field_clicked:
        try:
            await page.get_by_text("••••").first.click(timeout=4000)
            pwd_field_clicked = True
        except Exception:
            pass
    if not pwd_field_clicked:
        raise ChangePasswordError("Cannot find password field in Security settings")

    try:
        await page.wait_for_url("**/log-in/password**", timeout=12000)
        log("[chpwd] on verify current password page")
    except Exception:
        raise ChangePasswordError(f"Did not reach password verify page. URL: {page.url}")

    # Phase 3: Verify current password
    await asyncio.sleep(1.0)
    cur_input = None
    for sel in ('input[type="password"]',):
        try:
            loc = page.locator(sel).first
            if await loc.is_visible(timeout=8000):
                cur_input = loc
                break
        except Exception:
            continue
    if not cur_input:
        raise ChangePasswordError("Current password input not found on verify page")

    await cur_input.click(force=True)
    await cur_input.fill("")
    await cur_input.type(current_password, delay=40)
    for btn in ('button[type="submit"]', 'button:has-text("Continue")'):
        try:
            await page.click(btn, timeout=5000)
            break
        except Exception:
            continue

    try:
        await page.wait_for_url("**/reset-password/**", timeout=15000)
        log("[chpwd] on new password page")
    except Exception:
        content = await page.content()
        if any(x in content.lower() for x in ("wrong password", "incorrect", "invalid")):
            raise ChangePasswordError("Current password is incorrect")
        raise ChangePasswordError(f"Did not reach reset-password page. URL: {page.url}")

    # Phase 4: Set new password
    await asyncio.sleep(1.0)
    pwd_locs = page.locator('input[type="password"]')
    visible = []
    for i in range(await pwd_locs.count()):
        try:
            if await pwd_locs.nth(i).is_visible(timeout=2000):
                visible.append(pwd_locs.nth(i))
        except Exception:
            continue
    if not visible:
        raise ChangePasswordError("New password inputs not found on reset page")

    await visible[0].click(force=True)
    await visible[0].fill("")
    await visible[0].type(new_password, delay=40)
    if len(visible) >= 2:
        await visible[1].click(force=True)
        await visible[1].fill("")
        await visible[1].type(new_password, delay=40)
    log(f"[chpwd] new password filled ({len(visible)} field(s))")
    await asyncio.sleep(0.5)

    for btn in ('button[type="submit"]', 'button:has-text("Continue")'):
        try:
            await page.click(btn, timeout=5000)
            break
        except Exception:
            continue
    await asyncio.sleep(3.0)

    # Phase 5: MFA challenge after password reset (if any)
    await _fill_mfa_if_needed(page, secret, log, step="reset")
    log(f"[chpwd] ✓ password changed. URL: {page.url.split('?')[0]}")


async def _fill_mfa_if_needed(page: Any, secret: str | None, log: LogFn, step: str = "") -> None:
    """Fill TOTP code if currently on an MFA challenge page."""
    if "mfa-challenge" not in page.url:
        return
    if not secret:
        raise ChangePasswordError(f"2FA required at {step} but no secret provided")
    code = generate_code(secret)
    log(f"[chpwd] MFA at {step}, code: {code}")
    for sel in ('input[name="code"]', 'input[inputmode="numeric"]', 'input[maxlength="6"]'):
        try:
            loc = page.locator(sel).first
            if await loc.is_visible(timeout=5000):
                await loc.click(force=True)
                await loc.fill("")
                await loc.type(code, delay=60)
                await asyncio.sleep(0.5)
                for btn in ('button[type="submit"]', 'button:has-text("Continue")'):
                    try:
                        await page.click(btn, timeout=3000)
                        break
                    except Exception:
                        continue
                await asyncio.sleep(3.0)
                break
        except Exception:
            continue
